<?php

session_start();
header("location:userlogin.php");
session_destroy();

?>